package com.deniscerri.ytdl.database.viewmodel

import androidx.lifecycle.ViewModel
import com.deniscerri.ytdl.work.background.UpdateCheckWorker

/** State shared by the welcome pages. Nothing is written to preferences until the user finishes. */
class WelcomeViewModel : ViewModel() {
    var page = 0

    // set when a restored backup brought its own settings, so its folders may need access again
    var restoredSettings = false
    var updateApp = true
    var autoUpdateYtdlp = true
    var backgroundUpdateCheck = true
    var backgroundUpdateTypes = UpdateCheckWorker.DEFAULT_TYPES.toMutableSet()

    // matches what the yt-dlp update settings store: the value is a channel name or a repo, the label its title
    var ytdlpSource = "nightly"
    var ytdlpSourceLabel = ""
}